import React from 'react'
import style from './Logout.module.css'

export default function Logout() {
return <>
    <h2>Logout</h2>
</>
}
