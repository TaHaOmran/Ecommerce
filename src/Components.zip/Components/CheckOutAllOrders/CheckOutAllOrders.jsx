import React from 'react'
import style from './CheckOutAllOrders.module.css'

export default function CheckOutAllOrders() {
return <>
    <h2>CheckOutAllOrders</h2>
</>
}
