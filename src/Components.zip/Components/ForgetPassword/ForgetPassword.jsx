import React, { useState } from 'react'
import styles from './ForgetPassword.module.css'
import * as Yup from 'yup'
import { useFormik } from 'formik'
// import { Helmet } from 'react-helmet';
import { useContext } from 'react';
import toast from 'react-hot-toast';
import { useNavigate } from 'react-router-dom';
import { UserContext } from '../../context/userContext'

export default function ForgetPassword() {

    let { forgetPasswordApi, verifyResetCodeApi , setEmail } = useContext(UserContext);
    const [isLoading, setIsLoading] = useState(false);
    const [isResetCode, setIsResetCode] = useState(false);
    let navigate = useNavigate();

    async function handleForgetPassword(values) {
        setIsLoading(true);
        let res = await forgetPasswordApi(values);
        if (res?.data?.statusMsg === 'success') {
            setIsResetCode(true);
            setEmail(values.email);
            toast.success(res?.data?.message);
        }
        else {
            setIsResetCode(false);
            toast.error(res?.response?.data?.message ? res?.response?.data?.message : "Failed Operation");
        }
        setIsLoading(false);
    }
    
    let validationMail = Yup.object({
        email: Yup.string().required("email is required").email("email is invalid"),
    })
    let formik1 = useFormik({
        initialValues: {
            email: '',
        },
        onSubmit: handleForgetPassword,
        validationSchema: validationMail,
    });
    


    async function handleResetCode(values) {
    setIsLoading(true);  // تفعيل حالة التحميل
    console.log('Data being sent:', values);  // عرض البيانات المرسلة للتأكد

    try {
        // استدعاء دالة التحقق من الكود
        const res = await verifyResetCodeApi(values);
        console.log('Response:', res.data);  // عرض الاستجابة للتحقق من النجاح

        // التحقق من حالة الاستجابة
        if (res?.data?.status === 'Success') {
            toast.success('Correct Code');  // عرض رسالة نجاح
            navigate('/resetpassword');    // الانتقال لصفحة إعادة تعيين كلمة المرور
        } else {
            // في حالة وجود استجابة لكنها ليست ناجحة
            toast.error(res?.data?.message ? res.data.message : "Failed Operation");
        }

    } catch (err) {
        // معالجة الأخطاء القادمة من الخادم
        if (err.response) {
            console.error('Server Error:', err.response.data);  // طباعة تفاصيل الخطأ من الخادم

            // عرض رسالة الخطأ القادمة من الخادم
            if (err.response.data && err.response.data.message) {
                toast.error(err.response.data.message);
            } else {
                toast.error("Invalid response from server");
            }
        } else {
            // معالجة الأخطاء غير المتوقعة (مثل مشكلات الشبكة)
            console.error('Unexpected Error:', err.message);
            toast.error("An unexpected error occurred");
        }
    } finally {
        setIsLoading(false);  // إيقاف حالة التحميل في جميع الحالات
    }
}


    let validationCode = Yup.object({
        resetCode: Yup.number("resetCode must be numbers").required("resetCode is required"),
    })
    let formik2 = useFormik({
        initialValues: {
            resetCode: '',
        },
        onSubmit: handleResetCode,
        validationSchema: validationCode,
    });


    return <>
        <div className="max-w-lg mx-auto py-8">
            <h3 className="text-xl font-semibold mb-6 text-main">
                {isResetCode ? 'Reset Code' : 'Forget Password'}
            </h3>


            {isResetCode ? (
                <form onSubmit={formik2.handleSubmit} className="space-y-6">
                    <div className="relative group">
                        <input
                            type="password"
                            id="resetCode"
                            name="resetCode"
                            value={formik2.values.resetCode}
                            onChange={formik2.handleChange}
                            onBlur={formik2.handleBlur}
                            className="peer block w-full border-0 border-b-2 border-gray-300 bg-transparent px-0 py-2.5 text-sm text-gray-900 appearance-none focus:border-main focus:outline-none focus:ring-0"
                            placeholder=" "
                            required
                        />
                        <label
                            htmlFor="resetCode"
                            className="absolute top-3 z-10 origin-[0] scale-75 transform text-sm text-gray-500 duration-300 -translate-y-6 peer-placeholder-shown:translate-y-0 peer-placeholder-shown:scale-100 peer-focus:scale-75 peer-focus:-translate-y-6 peer-focus:text-main"
                        >
                            Enter Reset Code
                        </label>
                    </div>
                    {formik2.errors.resetCode && formik2.touched.resetCode && (
                        <div className="text-sm text-red-600 bg-red-50 p-2 rounded">{formik2.errors.resetCode}</div>
                    )}

                    <button
                        type="submit"
                        disabled={!formik2.isValid || !formik2.dirty || isLoading}
                        className={`w-full rounded bg-main px-5 py-2.5 text-white transition ${
                        !formik2.isValid || !formik2.dirty || isLoading
                            ? 'opacity-50 cursor-not-allowed'
                            : 'hover:bg-opacity-90'
                        }`}
                    >
                        {isLoading ? <i className="fas fa-spinner fa-spin" /> : 'Submit Code'}
                    </button>
                </form>
            ) : (
                <form onSubmit={formik1.handleSubmit} className="space-y-6">
                    <div className="relative group">
                        <input
                            type="email"
                            id="email"
                            name="email"
                            value={formik1.values.email}
                            onChange={formik1.handleChange}
                            onBlur={formik1.handleBlur}
                            className="peer block w-full border-0 border-b-2 border-gray-300 bg-transparent px-0 py-2.5 text-sm text-gray-900 appearance-none focus:border-main focus:outline-none focus:ring-0"
                            placeholder=" "
                            required
                        />
                        <label
                            htmlFor="email"
                            className="absolute top-3 z-10 origin-[0] scale-75 transform text-sm text-gray-500 duration-300 -translate-y-6 peer-placeholder-shown:translate-y-0 peer-placeholder-shown:scale-100 peer-focus:scale-75 peer-focus:-translate-y-6 peer-focus:text-main"
                        >
                            Enter Your Email
                        </label>
                    </div>
                    {formik1.errors.email && formik1.touched.email && (
                        <div className="text-sm text-red-600 bg-red-50 p-2 rounded">{formik1.errors.email}</div>
                    )}

                    <button
                        type="submit"
                        disabled={!formik1.isValid || !formik1.dirty || isLoading}
                        className={`w-full rounded bg-main px-5 py-2.5 text-white transition ${
                        !formik1.isValid || !formik1.dirty || isLoading
                            ? 'opacity-50 cursor-not-allowed'
                            : 'hover:bg-opacity-90'
                        }`}
                    >
                        {isLoading ? <i className="fas fa-spinner fa-spin" /> : 'Send Email'}
                    </button>
                </form>
            )}
        </div>
    </>
}
